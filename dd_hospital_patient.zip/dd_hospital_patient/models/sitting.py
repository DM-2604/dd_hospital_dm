from odoo import models, fields, api
from odoo.exceptions import UserError


class Patient(models.Model):
    _name = 'hospital.patient.sitting'
    _description = 'Patient Detail'

    sequence = fields.Char(copy=False, readonly=True, default="New", translate=True)
    patient_id = fields.Many2one('hospital.patient', string="Patient")
    treatment_name = fields.Char(string="Treatment name")
    treatment_date = fields.Date(string="Treatment date")
    treatment_charge = fields.Float(string="Treatment Charge")
    description_of_problem = fields.Text(string="Description of Problem")
    medications = fields.Text(string="Medications")
    image = fields.Binary(string="Sitting Image")
    paid = fields.Boolean(string="Paid")

    @api.model
    def create(self, val):
        sequence = self.env['ir.sequence'].next_by_code('sitting')
        val['sequence'] = sequence
        rtn = super(Patient, self).create(val)
        return rtn
