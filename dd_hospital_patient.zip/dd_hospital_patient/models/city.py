from odoo import models, fields, api
from odoo.exceptions import UserError


class City(models.Model):
    _name = 'res.state.city'
    _description = 'Automatically notifies users on status changes'

    name = fields.Char(string='City Name')
