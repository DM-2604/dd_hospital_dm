from odoo import models, fields, api
from odoo.exceptions import UserError
import base64
from PIL import Image, ImageDraw, ImageFont
import io
from datetime import date




class Patient(models.Model):
    _name = 'hospital.patient'
    _description = 'Patient Detail'


    sequence = fields.Char(copy=False, readonly=True, default="New",translate=True)
    name=fields.Char(string="Patient Name")
    city = fields.Many2one("res.state.city", string='City', ondelete='restrict')
    mo_number = fields.Char(string="Mobile Number")
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ], string="Gender")
    birth_date = fields.Date(string="Birth Date")
    image = fields.Binary(string="Profile Image")
    state = fields.Selection(
        [('draft','Draft'),
         ('in_progress','In Progress'),
         ('done','Done'),
         ('cancel','Cancel')],string="Treatment Status",default='draft'
    )
    age=fields.Integer(readonly=True,string="Age",store=True)
    paid=fields.Integer(readonly=True,string="Total Paid",store=True)
    unpaid=fields.Integer(readonly=True,string="Total Paid",store=True)
    sitting_detail=fields.One2many('hospital.patient.sitting','patient_id',string="Sitting Detail")


    @api.onchange('sitting_detail')
    def _count_paid(self):
        for rec in self:
            print(rec,"recccc")
            total_paid = 0
            total_unpaid = 0
            for sitting in rec.sitting_detail:

                if sitting.paid:
                    total_paid += sitting.treatment_charge
                if not sitting.paid:
                    total_unpaid += sitting.treatment_charge
            rec.paid=total_paid
            rec.unpaid=total_unpaid
            print(total_paid, "Total paid amount")
            print(total_unpaid, "Total paid amount")

    @api.model
    def create(self, val):
        sequence = self.env['ir.sequence'].next_by_code('patient')
        val['sequence'] = sequence
        rtn = super(Patient, self).create(val)
        return rtn

    def draft(self):
        self.state='draft'

    def progress(self):
        self.state='in_progress'

    def cancel(self):
        self.state='cancel'

    def done(self):
        self.state='done'

    @api.onchange('name','image')
    def _compute_image(self):
        for record in self:
            # Only generate image if no image is set
            if not record.image:
                if record.name :
                    first_letter = record.name[0].upper()  # Get first letter of name
                    img_size = (128, 128)
                    img = Image.new('RGB', img_size, color=(100, 0, 200))  # Background color
                    draw = ImageDraw.Draw(img)

                    try:
                        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 60)  # Adjust font path
                    except IOError:
                        font = ImageFont.load_default()  # Use default font if not found

                    # Get text bounding box (new method)
                    bbox = draw.textbbox((0, 0), first_letter, font=font)
                    text_width = bbox[2] - bbox[0]
                    text_height = bbox[3] - bbox[1]

                    text_x = (img_size[0] - text_width) // 2
                    text_y = (img_size[1] - text_height) // 2

                    draw.text((text_x, text_y), first_letter, font=font, fill=(255, 255, 255))  # White text

                    buffer = io.BytesIO()
                    img.save(buffer, format="PNG")
                    record.image = base64.b64encode(buffer.getvalue())

    @api.onchange('birth_date')
    def compute_age(self):
        if self.age:
            age=date.today().year-self.birth_date.year
            self.age=age
    def hospital_invoice(self):
         return self.env.ref('dd_hospital_patient.hospital_invoice').report_action(self)