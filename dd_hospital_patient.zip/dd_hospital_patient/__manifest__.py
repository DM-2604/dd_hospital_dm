{
    'name': 'Hospital',
    'sequence': 1,
    'data': [
        'security/ir.model.access.csv',
        'data/patient_seq.xml',
        'data/city_data.xml',
        'data/invioice.xml',
        'views/patient.xml',
        'views/patient_sitting.xml',
        'views/menu.xml',
        'report/patient_card.xml',


    ],
    'depends': ['base'],
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
